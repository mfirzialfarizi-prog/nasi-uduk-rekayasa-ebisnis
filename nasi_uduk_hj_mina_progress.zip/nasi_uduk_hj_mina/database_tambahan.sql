-- Opsional: tabel ini juga dibuat otomatis oleh koneksi.php saat halaman pertama diakses.
-- Jalankan file ini hanya jika Anda ingin membuatnya manual lewat phpMyAdmin.
USE db_nasi_uduk_hj_mina;

CREATE TABLE IF NOT EXISTS users(
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin') DEFAULT 'admin',
    dibuat TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS pesanan(
    id INT AUTO_INCREMENT PRIMARY KEY,
    kode VARCHAR(30) UNIQUE,
    nama_pemesan VARCHAR(100) DEFAULT 'Tamu',
    total INT,
    metode VARCHAR(20),
    status_bayar ENUM('Belum Bayar','Menunggu Verifikasi','Lunas') DEFAULT 'Belum Bayar',
    status_pesanan ENUM('Baru','Diproses','Siap','Selesai','Dibatalkan') DEFAULT 'Baru',
    catatan VARCHAR(255),
    transaksi_id INT NULL,
    tanggal TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS menu(
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_menu VARCHAR(100) NOT NULL,
    kategori ENUM('Nasi Uduk','Lauk','Tambahan','Minuman') NOT NULL,
    pilihan_lauk VARCHAR(100) NULL COMMENT 'Opsi lauk untuk menu Nasi Uduk, mis. Ayam/Telur/Bebek/Lele',
    level_pedas ENUM('Tidak Pedas','Sedang','Pedas','Sangat Pedas') DEFAULT 'Sedang',
    harga INT NOT NULL,
    status ENUM('Tersedia','Habis') DEFAULT 'Tersedia',
    foto VARCHAR(150) NULL,
    dibuat TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS pesanan_detail(
    id INT AUTO_INCREMENT PRIMARY KEY,
    pesanan_id INT,
    menu_id INT,
    jumlah INT,
    harga INT
);

-- Password default: admin123 (segera ganti setelah login pertama)
INSERT IGNORE INTO users(nama, username, password, role)
VALUES ('Administrator', 'admin', '$2y$10$z6bmj5SunrG0CIwQO7qjEOhff9lKEbhtdxZ34FUCwmKXLkMknnaTa', 'admin');
