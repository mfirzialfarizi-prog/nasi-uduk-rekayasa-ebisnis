<?php
define('BASE', '../');
include_once __DIR__."/../koneksi.php";
$halaman = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Nasi Uduk Hj. Mina</title>
<link rel="stylesheet" href="<?= BASE ?>assets/user.css">
</head>
<body>
<nav>
    <b>Nasi Uduk Hj. Mina</b>
    <span>
        <a href="beranda.php" class="<?= $halaman == 'beranda.php' ? 'aktif' : '' ?>">Beranda</a>
        <a href="katalog.php" class="<?= $halaman == 'katalog.php' ? 'aktif' : '' ?>">Katalog Menu</a>
        <a href="tentang.php" class="<?= $halaman == 'tentang.php' ? 'aktif' : '' ?>">Tentang Kami</a>
    </span>
</nav>
<main>
