<?php include "header.php"; ?>
<div class="box">
    <h1>Tentang Kami</h1>
    <p>
        Nasi Uduk Hj. Mina adalah usaha kuliner rumahan yang telah menyajikan nasi uduk
        khas Betawi sejak bertahun-tahun. Kami berkomitmen menggunakan bahan-bahan segar
        dan resep turun-temurun agar cita rasa gurih santan tetap terjaga di setiap porsi.
    </p>
    <p>
        Menu kami terdiri dari nasi uduk dengan berbagai pilihan lauk (ayam, telur, bebek,
        lele, ayam kremes) serta minuman pelengkap, dengan opsi tingkat kepedasan sambal
        sesuai selera pelanggan.
    </p>
</div>
