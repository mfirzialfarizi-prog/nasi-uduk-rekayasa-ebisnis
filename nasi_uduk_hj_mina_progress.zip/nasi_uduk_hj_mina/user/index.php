<?php
// Halaman default folder user/ -> arahkan ke Beranda
header("Location: beranda.php");
exit;
