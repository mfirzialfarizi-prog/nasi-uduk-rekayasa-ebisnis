<?php include "header.php"; ?>
<div class="box" style="text-align:center">
    <h1>Nasi Uduk Hj. Mina</h1>
    <p>Nasi uduk gurih khas Betawi dengan lauk pilihan, disiapkan segar setiap hari.</p>
    <p><a class="btn" href="katalog.php">Lihat Katalog Menu</a></p>
</div>

<div class="box">
    <h3>Kenapa Pilih Kami?</h3>
    <ul>
        <li>Bahan segar, dimasak setiap pagi</li>
        <li>Pilihan lauk dan level pedas sesuai selera</li>
        <li>Harga bersahabat untuk sekeluarga</li>
    </ul>
</div>
