<?php

$host     = "localhost";
$user     = "root";
$password = "";
$database = "db_nasi_uduk_hj_mina"; // 

$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

/* Tabel akun admin (login) */
mysqli_query($conn, "CREATE TABLE IF NOT EXISTS users(
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin') DEFAULT 'admin',
    dibuat TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

/* Pesanan online dari pelanggan (tanpa akun/login) */
mysqli_query($conn, "CREATE TABLE IF NOT EXISTS pesanan(
    id INT AUTO_INCREMENT PRIMARY KEY,
    kode VARCHAR(30) UNIQUE,
    nama_pemesan VARCHAR(100) DEFAULT 'Tamu',
    total INT,
    metode VARCHAR(20),
    status_bayar ENUM('Belum Bayar','Menunggu Verifikasi','Lunas') DEFAULT 'Belum Bayar',
    status_pesanan ENUM('Baru','Diproses','Siap','Selesai','Dibatalkan') DEFAULT 'Baru',
    catatan VARCHAR(255),
    transaksi_id INT NULL,
    tanggal TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");
mysqli_query($conn, "CREATE TABLE IF NOT EXISTS pesanan_detail(
    id INT AUTO_INCREMENT PRIMARY KEY,
    pesanan_id INT,
    menu_id INT,
    jumlah INT,
    harga INT
)");

/* Tabel menu: hasil modifikasi dari template dasar (barang umum) menjadi
   atribut khusus kuliner Nasi Uduk Hj. Mina */
mysqli_query($conn, "CREATE TABLE IF NOT EXISTS menu(
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_menu VARCHAR(100) NOT NULL,
    kategori ENUM('Nasi Uduk','Lauk','Tambahan','Minuman') NOT NULL,
    pilihan_lauk VARCHAR(100) NULL COMMENT 'Opsi lauk untuk menu Nasi Uduk, mis. Ayam/Telur/Bebek/Lele',
    level_pedas ENUM('Tidak Pedas','Sedang','Pedas','Sangat Pedas') DEFAULT 'Sedang',
    harga INT NOT NULL,
    status ENUM('Tersedia','Habis') DEFAULT 'Tersedia',
    foto VARCHAR(150) NULL,
    dibuat TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

/* Migrasi: tambahkan kolom nama_pemesan bila tabel pesanan sudah lebih dulu ada tanpa kolom ini */
$cek = mysqli_query($conn, "SHOW COLUMNS FROM pesanan LIKE 'nama_pemesan'");
if ($cek && mysqli_num_rows($cek) == 0) {
    mysqli_query($conn, "ALTER TABLE pesanan ADD COLUMN nama_pemesan VARCHAR(100) DEFAULT 'Tamu' AFTER kode");
}

if (!function_exists('tag')) {
    function tag($s) {
        $c = in_array($s, ['Lunas','Selesai','Siap']) ? 'g' : ($s == 'Dibatalkan' ? 'r' : 'y');
        return "<span class='tag $c'>$s</span>";
    }
}

/* Akun admin bawaan jika tabel users masih kosong */
if (mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM users"))[0] == 0) {
    $hash = password_hash('admin123', PASSWORD_DEFAULT);
    mysqli_query($conn, "INSERT INTO users(nama,username,password,role) VALUES('Administrator','admin','$hash','admin')");
}
?>